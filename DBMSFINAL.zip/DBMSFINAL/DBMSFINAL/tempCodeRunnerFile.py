import mysql.connector
from Employee import *
from Customer import *

mydb = mysql.connector.connect(
    host="localhost",
    user="root",
    password="KsaU3*>6",
    database="molkerei"
)